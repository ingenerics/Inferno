﻿using Inferno;

namespace $safeprojectname$.ViewModels
{
    public class DummyViewModel : Screen
    {
    }
}
