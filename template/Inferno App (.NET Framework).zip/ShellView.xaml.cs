﻿using Inferno;

namespace $safeprojectname$
{
    public partial class ShellView : RxWindow<ShellViewModel>
    {
        public ShellView()
        {
            InitializeComponent();

            this.WhenLoaded(d =>
            {
                this.OneWayBind(ViewModel,
                        viewModel => viewModel.ActiveItem,
                        view => view.Host.ViewModel)
                    .DisposeWith(d);

                this.OneWayBind(ViewModel,
                        vm => vm.WindowIcon,
                        v => v.IconTemplate,
                        vmToViewConverterOverride: new OcticonsKindToIconTemplateConverter())
                    .DisposeWith(d);
            });
        }
    }
}
