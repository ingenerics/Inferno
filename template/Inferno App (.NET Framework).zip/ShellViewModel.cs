﻿using Inferno;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class ShellViewModel : Conductor<IScreen>
    {
        private readonly IDialogManager _dialogManager;

        public ShellViewModel(IDialogManager dialogManager)
        {
            _dialogManager = dialogManager;
        }

        public PackIconOcticonsKind WindowIcon { get; private set; }

        protected override Task OnInitializeAsync(CancellationToken cancellationToken)
        {
            DisplayName = "Inferno";
            WindowIcon = PackIconOcticonsKind.MortarBoard;

            return Task.CompletedTask;
        }
    }
}