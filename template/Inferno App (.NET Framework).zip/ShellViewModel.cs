﻿using Inferno;
using $safeprojectname$.ViewModels;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class ShellViewModel : Conductor<DummyViewModel>
    {
        private readonly IDialogManager _dialogManager;

        public ShellViewModel(IDialogManager dialogManager)
        {
            _dialogManager = dialogManager;
        }

        public PackIconOcticonsKind WindowIcon { get; private set; }

        protected override Task OnInitializeAsync(CancellationToken cancellationToken)
        {
            DisplayName = "Inferno";
            WindowIcon = PackIconOcticonsKind.MortarBoard;

            ActiveItem = new DummyViewModel();

            return Task.CompletedTask;
        }
    }
}
