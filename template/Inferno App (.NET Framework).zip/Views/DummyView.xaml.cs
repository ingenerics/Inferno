﻿using Inferno;
using $safeprojectname$.ViewModels;

namespace $safeprojectname$.Views
{
    public partial class DummyView : RxUserControl<DummyViewModel>
    {
        public DummyView()
        {
            InitializeComponent();
        }
    }
}
