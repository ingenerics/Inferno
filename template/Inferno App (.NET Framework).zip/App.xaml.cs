﻿using $safeprojectname$.Bootstrap;
using System.Windows;

namespace $safeprojectname$
{
    public partial class App : Application
    {
        public App()
        {
            new AppBootstrapper(this);
        }
    }
}
